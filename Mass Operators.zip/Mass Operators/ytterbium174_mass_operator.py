
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Ytterbium-174
A0 = 10039.250216835066
k1 = 7.968
k2 = 3.688
gamma = 0.648

def mass_operator_yb174(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_yb174(R=4.685):
    result, _ = quad(mass_operator_yb174, 0, R)
    return result
