
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Arsenic-75
A0 = 4444.82537968143
k1 = 8.561017593244195
k2 = 3.7288881069669246
gamma = 0.6493103448275861

def mass_operator_as75(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_as75(R=3.999):
    result, _ = quad(mass_operator_as75, 0, R)
    return result
