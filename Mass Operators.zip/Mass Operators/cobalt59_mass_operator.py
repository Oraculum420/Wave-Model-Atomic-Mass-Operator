
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Cobalt-59
A0 = 3656.8017904768417
k1 = 9.132446164672766
k2 = 3.5695665024630543
gamma = 0.7145517241379311

def mass_operator_co59(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_co59(R=3.748):
    result, _ = quad(mass_operator_co59, 0, R)
    return result
