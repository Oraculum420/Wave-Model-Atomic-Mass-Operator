
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Flerovium-289
A0 = 14486.968121851829
k1 = 8.077959605911328
k2 = 3.739510344827586
gamma = 0.8142699507389162

def mass_operator_fl289(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_fl289(R=4.543):
    result, _ = quad(mass_operator_fl289, 0, R)
    return result
