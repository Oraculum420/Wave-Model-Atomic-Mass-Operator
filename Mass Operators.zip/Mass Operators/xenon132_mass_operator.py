
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Xenon-132
A0 = 6648.362066798625
k1 = 8.324080788177339
k2 = 3.775833497536946
gamma = 0.6933330049261084

def mass_operator_xe132(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_xe132(R=4.469):
    result, _ = quad(mass_operator_xe132, 0, R)
    return result
