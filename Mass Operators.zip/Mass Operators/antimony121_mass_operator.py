
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Antimony-121
A0 = 6427.007840081887
k1 = 8.375862068965517
k2 = 3.7378738916256156
gamma = 0.6921842364532019

def mass_operator_sb121(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_sb121(R=4.434):
    result, _ = quad(mass_operator_sb121, 0, R)
    return result
