
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Oxygen-16
A0 = 793.0459293373782
k1 = 8.060900351864884
k2 = 3.2901752287121746
gamma = 0.6608620689655172

def mass_operator_o16(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_o16(R=2.6991):
    result, _ = quad(mass_operator_o16, 0, R)
    return result
