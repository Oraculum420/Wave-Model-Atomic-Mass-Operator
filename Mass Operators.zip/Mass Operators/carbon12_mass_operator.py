
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Carbon-12
A0 = -2220.8405955178678
k1 = 7.602254609429979
k2 = 2.671434904996482
gamma = 0.5659241379310345

def mass_operator_c12(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_c12(R=2.4702):
    result, _ = quad(mass_operator_c12, 0, R)
    return result
