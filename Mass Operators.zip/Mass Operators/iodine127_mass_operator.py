
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Iodine-127
A0 = 6593.695391322383
k1 = 8.34143645320197
k2 = 3.744656157635468
gamma = 0.6941389162561575

def mass_operator_i127(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_i127(R=4.455):
    result, _ = quad(mass_operator_i127, 0, R)
    return result
