
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Iron-56
A0 = 3375.9076842160853
k1 = 9.173986629134411
k2 = 3.536259394792399
gamma = 0.6128482758620689

def mass_operator_fe56(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_fe56(R=3.737):
    result, _ = quad(mass_operator_fe56, 0, R)
    return result
