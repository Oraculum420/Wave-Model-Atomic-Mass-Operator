
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Rhenium-187
A0 = 8728.660104142975
k1 = 7.983687840290381
k2 = 3.706007259528131
gamma = 0.6440526315789474

def mass_operator_re187(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_re187(R=4.666):
    result, _ = quad(mass_operator_re187, 0, R)
    return result
