
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Plutonium-244
A0 = 12000.755860030687
k1 = 8.063476847290639
k2 = 3.72816157635468
gamma = 0.7399428571428571

def mass_operator_pu244(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_pu244(R=4.593):
    result, _ = quad(mass_operator_pu244, 0, R)
    return result
