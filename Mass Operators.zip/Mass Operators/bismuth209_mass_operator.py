
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Bismuth-209
A0 = 9961.316878113897
k1 = 8.048018148820326
k2 = 3.7363520871143376
gamma = 0.6706842105263159

def mass_operator_bi209(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_bi209(R=4.624):
    result, _ = quad(mass_operator_bi209, 0, R)
    return result
