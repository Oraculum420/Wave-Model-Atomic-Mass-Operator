
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Iridium-193
A0 = 9101.151239946048
k1 = 8.0006039408867
k2 = 3.732613793103448
gamma = 0.6544758620689656

def mass_operator_ir193(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ir193(R=4.654):
    result, _ = quad(mass_operator_ir193, 0, R)
    return result
