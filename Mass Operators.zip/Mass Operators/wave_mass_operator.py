
import numpy as np
from scipy.integrate import quad

def mass_operator(r, A0, k1, k2, gamma):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass(A0, k1, k2, gamma, R):
    result, _ = quad(mass_operator, 0, R, args=(A0, k1, k2, gamma))
    return result
