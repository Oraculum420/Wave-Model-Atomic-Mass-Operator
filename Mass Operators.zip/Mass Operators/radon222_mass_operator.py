
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Radon-222
A0 = 10709.25493526184
k1 = 8.063343012704173
k2 = 3.734762250453721
gamma = 0.6913466424682395

def mass_operator_rn222(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_rn222(R=4.610):
    result, _ = quad(mass_operator_rn222, 0, R)
    return result
