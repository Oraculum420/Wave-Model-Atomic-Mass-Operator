
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Uranium-238
A0 = 11669.964739930962
k1 = 8.064185117967332
k2 = 3.721157894736842
gamma = 0.7253157894736841

def mass_operator_u238(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_u238(R=4.598):
    result, _ = quad(mass_operator_u238, 0, R)
    return result
