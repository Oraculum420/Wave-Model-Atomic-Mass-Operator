
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Platinum-195
A0 = 9175.81024418736
k1 = 8.010660617059893
k2 = 3.726312159709619
gamma = 0.6525045372050817

def mass_operator_pt195(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_pt195(R=4.649):
    result, _ = quad(mass_operator_pt195, 0, R)
    return result
