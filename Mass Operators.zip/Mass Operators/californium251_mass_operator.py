
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Californium-251
A0 = 12424.583501189387
k1 = 8.078016748768471
k2 = 3.72816157635468
gamma = 0.7517822660098522

def mass_operator_cf251(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_cf251(R=4.580):
    result, _ = quad(mass_operator_cf251, 0, R)
    return result
