
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Boron-11
A0 = -1817.0636706150694
k1 = 7.328523715693174
k2 = 2.595911470795215
gamma = 0.5206264367816092

def mass_operator_b11(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_b11(R=2.43):
    result, _ = quad(mass_operator_b11, 0, R)
    return result
