
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Dysprosium-164
A0 = 9691.627623389864
k1 = 7.998
k2 = 3.701350272232305
gamma = 0.662

def mass_operator_dy164(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_dy164(R=4.666):
    result, _ = quad(mass_operator_dy164, 0, R)
    return result
