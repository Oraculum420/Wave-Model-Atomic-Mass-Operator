
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Thulium-169
A0 = 9530.461001479576
k1 = 7.968
k2 = 3.6890526315789476
gamma = 0.652

def mass_operator_tm169(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_tm169(R=4.683):
    result, _ = quad(mass_operator_tm169, 0, R)
    return result
