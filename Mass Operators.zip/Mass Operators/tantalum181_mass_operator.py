
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Tantalum-181
A0 = 8424.508667580536
k1 = 7.957931034482759
k2 = 3.699253201970443
gamma = 0.6416206896551724

def mass_operator_ta181(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ta181(R=4.681):
    result, _ = quad(mass_operator_ta181, 0, R)
    return result
