
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Cerium-140
A0 = 9080.012961938122
k1 = 8.097999999999999
k2 = 3.744301270417423
gamma = 0.683

def mass_operator_ce140(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ce140(R=4.610):
    result, _ = quad(mass_operator_ce140, 0, R)
    return result
