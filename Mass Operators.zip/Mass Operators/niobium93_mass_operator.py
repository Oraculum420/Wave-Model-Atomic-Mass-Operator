
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Niobium-93
A0 = 5841.536586425417
k1 = 8.47221379310345
k2 = 3.744856157635468
gamma = 0.6835625615763548

def mass_operator_nb93(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_nb93(R=4.275):
    result, _ = quad(mass_operator_nb93, 0, R)
    return result
