
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Dubnium-268
A0 = 13386.962275933103
k1 = 8.077816748768472
k2 = 3.725431527093596
gamma = 0.7821891625615763

def mass_operator_db268(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_db268(R=4.564):
    result, _ = quad(mass_operator_db268, 0, R)
    return result
