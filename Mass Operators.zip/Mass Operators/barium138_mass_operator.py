
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Barium-138
A0 = 6836.3991831792055
k1 = 8.135430127041744
k2 = 3.700105263157895
gamma = 0.6944736842105262

def mass_operator_ba138(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ba138(R=4.567):
    result, _ = quad(mass_operator_ba138, 0, R)
    return result
