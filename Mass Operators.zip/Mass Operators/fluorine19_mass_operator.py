
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Fluorine-19
A0 = 824.6841019254638
k1 = 7.500158620689655
k2 = 3.02282772695285
gamma = 0.671303448275862

def mass_operator_f19(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_f19(R=2.897):
    result, _ = quad(mass_operator_f19, 0, R)
    return result
