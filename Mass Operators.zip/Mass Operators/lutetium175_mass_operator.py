
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Lutetium-175
A0 = 8686.453471178713
k1 = 7.958
k2 = 3.6911397459165154
gamma = 0.644

def mass_operator_lu175(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_lu175(R=4.684):
    result, _ = quad(mass_operator_lu175, 0, R)
    return result
