
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Nickel-58
A0 = 3906.2349540380433
k1 = 9.051758339197747
k2 = 3.4743038705137224
gamma = 0.6852206896551724

def mass_operator_ni58(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ni58(R=3.775):
    result, _ = quad(mass_operator_ni58, 0, R)
    return result
