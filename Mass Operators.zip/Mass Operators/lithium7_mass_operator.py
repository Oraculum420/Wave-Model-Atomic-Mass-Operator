
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Lithium-7
A0 = -227.29178991250467
k1 = 6.387881632653061
k2 = 2.1196204081632652
gamma = 0.5157786066150598

def mass_operator_li7(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_li7(R=2.44):
    result, _ = quad(mass_operator_li7, 0, R)
    return result
