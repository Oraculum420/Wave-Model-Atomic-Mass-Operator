
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Erbium-166
A0 = 8907.610676322538
k1 = 7.968
k2 = 3.6922323049001817
gamma = 0.654

def mass_operator_er166(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_er166(R=4.680):
    result, _ = quad(mass_operator_er166, 0, R)
    return result
