
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Hydrogen-1
A0 = 4.984932547479036
k1 = 12.347030612244897
k2 = 13.979944897959184
gamma = 1.2756479591836734

def mass_operator_h1(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_h1(R=0.8414):
    result, _ = quad(mass_operator_h1, 0, R)
    return result
