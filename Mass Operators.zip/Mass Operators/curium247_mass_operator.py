
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Curium-247
A0 = 12119.949119561004
k1 = 8.076773139745915
k2 = 3.7615789473684207
gamma = 0.7418421052631579

def mass_operator_cm247(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_cm247(R=4.586):
    result, _ = quad(mass_operator_cm247, 0, R)
    return result
