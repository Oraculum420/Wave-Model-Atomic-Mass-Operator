
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Argon-40
A0 = 1750.1492194888629
k1 = 7.664161857846587
k2 = 3.7546192821956366
gamma = 0.7188275862068966

def mass_operator_ar40(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ar40(R=3.427):
    result, _ = quad(mass_operator_ar40, 0, R)
    return result
