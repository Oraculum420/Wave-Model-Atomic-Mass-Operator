
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Seaborgium-271
A0 = 13573.817598630838
k1 = 8.0779881773399
k2 = 3.721322167487685
gamma = 0.7859083743842364

def mass_operator_sg271(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_sg271(R=4.561):
    result, _ = quad(mass_operator_sg271, 0, R)
    return result
