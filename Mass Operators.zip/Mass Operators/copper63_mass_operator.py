
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Copper-63
A0 = 6205.191858549923
k1 = 8.23448008444757
k2 = 3.9872654468684026
gamma = 0.6341586206896551

def mass_operator_cu63(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_cu63(R=3.882):
    result, _ = quad(mass_operator_cu63, 0, R)
    return result
