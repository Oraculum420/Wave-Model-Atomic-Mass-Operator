
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Magnesium-24
A0 = 960.8032677366398
k1 = 8.112348346235045
k2 = 3.3088454609429983
gamma = 0.6940620689655171

def mass_operator_mg24(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_mg24(R=3.057):
    result, _ = quad(mass_operator_mg24, 0, R)
    return result
