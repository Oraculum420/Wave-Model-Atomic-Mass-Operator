
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Tungsten-184
A0 = 8601.522456622943
k1 = 7.975143842364532
k2 = 3.699310344827586
gamma = 0.6473674876847291

def mass_operator_w184(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_w184(R=4.670):
    result, _ = quad(mass_operator_w184, 0, R)
    return result
