
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Europium-153
A0 = 12302.844893525613
k1 = 8.048
k2 = 3.7103157894736842
gamma = 0.67

def mass_operator_eu153(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_eu153(R=4.649):
    result, _ = quad(mass_operator_eu153, 0, R)
    return result
