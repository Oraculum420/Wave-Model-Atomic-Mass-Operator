
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Lawrencium-262
A0 = 12990.685099917782
k1 = 8.0790889292196
k2 = 3.746196007259528
gamma = 0.7773974591651543

def mass_operator_lr262(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_lr262(R=4.568):
    result, _ = quad(mass_operator_lr262, 0, R)
    return result
