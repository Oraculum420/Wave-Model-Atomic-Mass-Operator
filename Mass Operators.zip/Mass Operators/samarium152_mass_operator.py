
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Samarium-152
A0 = 12209.043818773804
k1 = 8.058
k2 = 3.7151433756805807
gamma = 0.672

def mass_operator_sm152(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_sm152(R=4.643):
    result, _ = quad(mass_operator_sm152, 0, R)
    return result
