
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Phosphorus-31
A0 = 1132.2392880796929
k1 = 7.785941871921182
k2 = 3.655137086558761
gamma = 0.6843655172413793

def mass_operator_p31(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_p31(R=3.188):
    result, _ = quad(mass_operator_p31, 0, R)
    return result
