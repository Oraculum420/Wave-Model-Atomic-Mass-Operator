
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Yttrium-89
A0 = 5541.271922469828
k1 = 8.766554398311047
k2 = 3.7922160450387046
gamma = 0.5842

def mass_operator_y89(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_y89(R=4.227):
    result, _ = quad(mass_operator_y89, 0, R)
    return result
