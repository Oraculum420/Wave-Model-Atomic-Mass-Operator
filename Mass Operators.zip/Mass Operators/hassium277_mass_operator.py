
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Hassium-277
A0 = 13787.319588814331
k1 = 8.078102463054186
k2 = 3.746349753694581
gamma = 0.7967822660098522

def mass_operator_hs277(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_hs277(R=4.557):
    result, _ = quad(mass_operator_hs277, 0, R)
    return result
