
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Zinc-64
A0 = 6187.420889564485
k1 = 8.562776213933851
k2 = 3.950792821956369
gamma = 0.6811103448275861

def mass_operator_zn64(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_zn64(R=3.928):
    result, _ = quad(mass_operator_zn64, 0, R)
    return result
