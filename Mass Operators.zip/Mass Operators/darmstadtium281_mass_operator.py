
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Darmstadtium-281
A0 = 14082.409455329896
k1 = 8.076983666061704
k2 = 3.7302758620689653
gamma = 0.8017096188747732

def mass_operator_ds281(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ds281(R=4.552):
    result, _ = quad(mass_operator_ds281, 0, R)
    return result
