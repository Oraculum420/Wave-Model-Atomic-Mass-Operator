
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Silver-107
A0 = 5811.726895196006
k1 = 8.495604355716877
k2 = 3.775967332123412
gamma = 0.6895480943738658

def mass_operator_ag107(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ag107(R=4.373):
    result, _ = quad(mass_operator_ag107, 0, R)
    return result
