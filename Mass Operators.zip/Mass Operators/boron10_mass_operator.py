
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Boron-10
A0 = 1150.5682780347813
k1 = 7.9598571428571425
k2 = 2.614248979591837
gamma = 0.5464007037297679

def mass_operator_b10(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_b10(R=2.43):
    result, _ = quad(mass_operator_b10, 0, R)
    return result
