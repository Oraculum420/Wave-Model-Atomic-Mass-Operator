
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Tellurium-130
A0 = 6845.678693342997
k1 = 8.358706403940886
k2 = 3.734568472906404
gamma = 0.6876443349753695

def mass_operator_te130(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_te130(R=4.445):
    result, _ = quad(mass_operator_te130, 0, R)
    return result
