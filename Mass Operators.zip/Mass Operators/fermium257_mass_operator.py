
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Fermium-257
A0 = 12796.42503133749
k1 = 8.077759605911329
k2 = 3.7198285714285717
gamma = 0.7631024630541873

def mass_operator_fm257(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_fm257(R=4.574):
    result, _ = quad(mass_operator_fm257, 0, R)
    return result
