
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Neodymium-142
A0 = 10326.987017988504
k1 = 8.078
k2 = 3.7289945553539017
gamma = 0.678

def mass_operator_nd142(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_nd142(R=4.627):
    result, _ = quad(mass_operator_nd142, 0, R)
    return result
