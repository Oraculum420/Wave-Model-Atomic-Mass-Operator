
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Astatine-210
A0 = 10105.027473416456
k1 = 8.05096551724138
k2 = 3.7180000000000004
gamma = 0.686

def mass_operator_at210(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_at210(R=4.618):
    result, _ = quad(mass_operator_at210, 0, R)
    return result
