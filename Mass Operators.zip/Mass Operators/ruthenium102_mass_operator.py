
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Ruthenium-102
A0 = 6105.76445902253
k1 = 8.476004926108374
k2 = 3.7208039408866993
gamma = 0.6910049261083743

def mass_operator_ru102(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ru102(R=4.334):
    result, _ = quad(mass_operator_ru102, 0, R)
    return result
