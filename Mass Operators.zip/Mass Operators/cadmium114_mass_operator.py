
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Cadmium-114
A0 = 6388.778579972741
k1 = 8.427671921182265
k2 = 3.724109359605911
gamma = 0.6948571428571428

def mass_operator_cd114(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_cd114(R=4.394):
    result, _ = quad(mass_operator_cd114, 0, R)
    return result
