
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Chlorine-35
A0 = 4855.055749481642
k1 = 9.458225052779733
k2 = 3.779433216045039
gamma = 0.631303448275862

def mass_operator_cl35(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_cl35(R=3.365):
    result, _ = quad(mass_operator_cl35, 0, R)
    return result
