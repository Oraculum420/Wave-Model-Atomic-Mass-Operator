
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Holmium-165
A0 = 8481.353230083676
k1 = 7.978000000000001
k2 = 3.7000653357531754
gamma = 0.658

def mass_operator_ho165(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ho165(R=4.671):
    result, _ = quad(mass_operator_ho165, 0, R)
    return result
