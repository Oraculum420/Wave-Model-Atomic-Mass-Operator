
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Sodium-23
A0 = 911.8892756220288
k1 = 8.152750879662209
k2 = 3.3332387051372274
gamma = 0.6957724137931034

def mass_operator_na23(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_na23(R=3.043):
    result, _ = quad(mass_operator_na23, 0, R)
    return result
