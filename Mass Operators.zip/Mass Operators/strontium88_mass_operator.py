
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Strontium-88
A0 = 8262.81226946854
k1 = 7.5396783954961295
k2 = 3.6445462350457425
gamma = 0.5839379310344828

def mass_operator_sr88(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_sr88(R=4.219):
    result, _ = quad(mass_operator_sr88, 0, R)
    return result
