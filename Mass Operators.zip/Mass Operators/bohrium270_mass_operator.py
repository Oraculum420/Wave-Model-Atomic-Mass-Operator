
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Bohrium-270
A0 = 13478.210411849748
k1 = 8.0779881773399
k2 = 3.7338788177339906
gamma = 0.7916955665024631

def mass_operator_bh270(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_bh270(R=4.559):
    result, _ = quad(mass_operator_bh270, 0, R)
    return result
