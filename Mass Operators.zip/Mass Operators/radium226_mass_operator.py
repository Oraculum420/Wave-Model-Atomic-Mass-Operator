
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Radium-226
A0 = 10902.505062682822
k1 = 8.059491833030853
k2 = 3.7303920145190563
gamma = 0.6914664246823956

def mass_operator_ra226(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ra226(R=4.612):
    result, _ = quad(mass_operator_ra226, 0, R)
    return result
