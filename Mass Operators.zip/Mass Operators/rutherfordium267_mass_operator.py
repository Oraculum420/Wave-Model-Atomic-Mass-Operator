
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Rutherfordium-267
A0 = 13227.783605787918
k1 = 8.077845320197044
k2 = 3.7531891625615765
gamma = 0.7829822660098522

def mass_operator_rf267(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_rf267(R=4.566):
    result, _ = quad(mass_operator_rf267, 0, R)
    return result
