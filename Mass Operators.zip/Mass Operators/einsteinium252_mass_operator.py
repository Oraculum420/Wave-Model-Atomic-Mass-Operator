
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Einsteinium-252
A0 = 12523.827802941641
k1 = 8.078102463054186
k2 = 3.7201142857142857
gamma = 0.7567251231527093

def mass_operator_es252(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_es252(R=4.577):
    result, _ = quad(mass_operator_es252, 0, R)
    return result
