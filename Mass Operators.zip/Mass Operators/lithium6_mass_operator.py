
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Lithium-6
A0 = -140.3708651393422
k1 = 6.010226530612245
k2 = 1.9939316326530612
gamma = 0.4190234693877551

def mass_operator_li6(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_li6(R=2.59):
    result, _ = quad(mass_operator_li6, 0, R)
    return result
