
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Nobelium-259
A0 = 12856.330144542877
k1 = 8.078016748768471
k2 = 3.738045320197044
gamma = 0.7736669950738916

def mass_operator_no259(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_no259(R=4.570):
    result, _ = quad(mass_operator_no259, 0, R)
    return result
