
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Mendelevium-258
A0 = 12837.985786868641
k1 = 8.078102463054186
k2 = 3.7255458128078818
gamma = 0.7677251231527094

def mass_operator_md258(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_md258(R=4.572):
    result, _ = quad(mass_operator_md258, 0, R)
    return result
