
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Vanadium-51
A0 = 10204.54773579435
k1 = 8.847111189303307
k2 = 3.5951942294159047
gamma = 0.6122827586206897

def mass_operator_v51(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_v51(R=3.570):
    result, _ = quad(mass_operator_v51, 0, R)
    return result
