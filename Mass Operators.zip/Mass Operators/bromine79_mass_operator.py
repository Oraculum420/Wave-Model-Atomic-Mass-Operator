
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Bromine-79
A0 = 4662.550024190147
k1 = 8.520594370161858
k2 = 3.717850105559465
gamma = 0.6230689655172413

def mass_operator_br79(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_br79(R=4.020):
    result, _ = quad(mass_operator_br79, 0, R)
    return result
