
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Potassium-39
A0 = 1520.430803581724
k1 = 8.071766502463053
k2 = 3.767615904292751
gamma = 0.5848068965517241

def mass_operator_k39(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_k39(R=3.4349):
    result, _ = quad(mass_operator_k39, 0, R)
    return result
