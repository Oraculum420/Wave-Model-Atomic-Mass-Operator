
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Hafnium-180
A0 = 8369.258276838384
k1 = 7.956352087114339
k2 = 3.6917931034482763
gamma = 0.6411578947368421

def mass_operator_hf180(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_hf180(R=4.682):
    result, _ = quad(mass_operator_hf180, 0, R)
    return result
