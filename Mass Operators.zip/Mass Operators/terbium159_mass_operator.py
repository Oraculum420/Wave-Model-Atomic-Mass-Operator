
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Terbium-159
A0 = 12050.557678643769
k1 = 8.027999999999999
k2 = 3.703284936479129
gamma = 0.665

def mass_operator_tb159(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_tb159(R=4.659):
    result, _ = quad(mass_operator_tb159, 0, R)
    return result
