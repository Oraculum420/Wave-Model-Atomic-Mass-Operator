
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Chromium-52
A0 = 2848.9214617469547
k1 = 9.418181140042226
k2 = 3.802543701618579
gamma = 0.7014413793103448

def mass_operator_cr52(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_cr52(R=3.643):
    result, _ = quad(mass_operator_cr52, 0, R)
    return result
