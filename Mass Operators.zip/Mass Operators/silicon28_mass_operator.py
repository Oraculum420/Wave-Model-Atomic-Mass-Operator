
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Silicon-28
A0 = 1039.89056545515
k1 = 7.949786488388459
k2 = 3.2630382828993665
gamma = 0.6599241379310344

def mass_operator_si28(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_si28(R=3.1224):
    result, _ = quad(mass_operator_si28, 0, R)
    return result
