
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Helium-4
A0 = -481.8591526303598
k1 = 5.467010204081633
k2 = 1.9140612244897959
gamma = 0.43123469387755103

def mass_operator_he4(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_he4(R=1.6755):
    result, _ = quad(mass_operator_he4, 0, R)
    return result
