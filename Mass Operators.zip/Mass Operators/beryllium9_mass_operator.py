
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Beryllium-9
A0 = 1386.5942588525816
k1 = 6.321351020408163
k2 = 2.45325306122449
gamma = 0.4855235749472203

def mass_operator_be9(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_be9(R=2.519):
    result, _ = quad(mass_operator_be9, 0, R)
    return result
