
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Osmium-192
A0 = 9166.668823453425
k1 = 7.9853720508166965
k2 = 3.761157894736842
gamma = 0.6601052631578948

def mass_operator_os192(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_os192(R=4.660):
    result, _ = quad(mass_operator_os192, 0, R)
    return result
