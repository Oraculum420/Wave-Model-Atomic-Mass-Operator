
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Germanium-74
A0 = 12469.798873921844
k1 = 7.907894299788881
k2 = 3.570732019704433
gamma = 0.7000068965517241

def mass_operator_ge74(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ge74(R=3.985):
    result, _ = quad(mass_operator_ge74, 0, R)
    return result
