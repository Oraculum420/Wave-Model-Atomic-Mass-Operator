
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Neptunium-237
A0 = 11638.034873010116
k1 = 8.063362561576355
k2 = 3.72408078817734
gamma = 0.7321142857142857

def mass_operator_np237(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_np237(R=4.596):
    result, _ = quad(mass_operator_np237, 0, R)
    return result
