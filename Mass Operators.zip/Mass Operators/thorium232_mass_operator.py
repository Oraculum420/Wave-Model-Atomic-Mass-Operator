
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Thorium-232
A0 = 11312.48850245229
k1 = 8.06544827586207
k2 = 3.7184210526315793
gamma = 0.7087894736842105

def mass_operator_th232(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_th232(R=4.603):
    result, _ = quad(mass_operator_th232, 0, R)
    return result
