
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Nitrogen-14
A0 = -631.7812508463328
k1 = 7.326606474313864
k2 = 2.928027163969036
gamma = 0.586903448275862

def mass_operator_n14(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_n14(R=2.5582):
    result, _ = quad(mass_operator_n14, 0, R)
    return result
