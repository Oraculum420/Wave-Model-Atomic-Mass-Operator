
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Lead-208
A0 = 9923.162090290405
k1 = 8.041407881773399
k2 = 3.7382472906403943
gamma = 0.6730463054187192

def mass_operator_pb208(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_pb208(R=4.627):
    result, _ = quad(mass_operator_pb208, 0, R)
    return result
