
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Mercury-202
A0 = 9598.460925436706
k1 = 8.027500492610837
k2 = 3.710489655172414
gamma = 0.6670679802955666

def mass_operator_hg202(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_hg202(R=4.636):
    result, _ = quad(mass_operator_hg202, 0, R)
    return result
