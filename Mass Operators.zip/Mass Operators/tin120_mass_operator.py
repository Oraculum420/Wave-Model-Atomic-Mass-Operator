
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Tin-120
A0 = 6554.6427208375435
k1 = 8.39330344827586
k2 = 3.720832512315271
gamma = 0.6865527093596059

def mass_operator_sn120(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_sn120(R=4.420):
    result, _ = quad(mass_operator_sn120, 0, R)
    return result
