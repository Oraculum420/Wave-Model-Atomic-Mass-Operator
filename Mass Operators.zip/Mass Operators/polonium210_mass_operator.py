
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Polonium-210
A0 = 10061.598367949711
k1 = 8.04896551724138
k2 = 3.7257172413793103
gamma = 0.6797586206896552

def mass_operator_po210(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_po210(R=4.621):
    result, _ = quad(mass_operator_po210, 0, R)
    return result
