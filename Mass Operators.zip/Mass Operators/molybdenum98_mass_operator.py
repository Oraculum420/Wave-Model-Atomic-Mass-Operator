
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Molybdenum-98
A0 = 5918.63899209735
k1 = 8.517412807881774
k2 = 3.734511330049261
gamma = 0.6861497536945812

def mass_operator_mo98(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_mo98(R=4.313):
    result, _ = quad(mass_operator_mo98, 0, R)
    return result
