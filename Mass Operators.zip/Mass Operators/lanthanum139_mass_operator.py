
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Lanthanum-139
A0 = 6716.855426737972
k1 = 8.097999999999999
k2 = 3.762174228675136
gamma = 0.683

def mass_operator_la139(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_la139(R=4.594):
    result, _ = quad(mass_operator_la139, 0, R)
    return result
