
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Scandium-45
A0 = 1421.3074192314368
k1 = 7.867415904292751
k2 = 3.8389542575650952
gamma = 0.656206896551724

def mass_operator_sc45(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_sc45(R=3.545):
    result, _ = quad(mass_operator_sc45, 0, R)
    return result
