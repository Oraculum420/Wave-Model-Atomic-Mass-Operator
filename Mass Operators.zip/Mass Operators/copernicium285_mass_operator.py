
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Copernicium-285
A0 = 14355.41061425785
k1 = 8.077959605911328
k2 = 3.7214935960591133
gamma = 0.803856157635468

def mass_operator_cn285(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_cn285(R=4.548):
    result, _ = quad(mass_operator_cn285, 0, R)
    return result
