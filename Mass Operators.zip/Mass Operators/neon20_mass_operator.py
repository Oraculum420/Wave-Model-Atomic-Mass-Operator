
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Neon-20
A0 = 694.2657564478634
k1 = 8.275710204081632
k2 = 3.454640534834623
gamma = 0.661703448275862

def mass_operator_ne20(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ne20(R=3.0055):
    result, _ = quad(mass_operator_ne20, 0, R)
    return result
