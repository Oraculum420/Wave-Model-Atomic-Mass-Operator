
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Selenium-80
A0 = 7692.703850264435
k1 = 8.355522167487685
k2 = 3.878247572132301
gamma = 0.6751103448275861

def mass_operator_se80(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_se80(R=4.005):
    result, _ = quad(mass_operator_se80, 0, R)
    return result
