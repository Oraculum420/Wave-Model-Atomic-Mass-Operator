
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Americium-243
A0 = 12006.56081195338
k1 = 8.06544827586207
k2 = 3.7184210526315793
gamma = 0.7454736842105263

def mass_operator_am243(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_am243(R=4.589):
    result, _ = quad(mass_operator_am243, 0, R)
    return result
