
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Indium-115
A0 = 5955.382806198287
k1 = 8.44488472906404
k2 = 3.7966660098522165
gamma = 0.6890807881773399

def mass_operator_in115(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_in115(R=4.406):
    result, _ = quad(mass_operator_in115, 0, R)
    return result
