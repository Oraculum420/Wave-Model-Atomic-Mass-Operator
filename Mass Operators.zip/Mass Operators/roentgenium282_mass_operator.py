
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Roentgenium-282
A0 = 14139.006120949816
k1 = 8.077404718693284
k2 = 3.7312558983666064
gamma = 0.8042431941923776

def mass_operator_rg282(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_rg282(R=4.550):
    result, _ = quad(mass_operator_rg282, 0, R)
    return result
