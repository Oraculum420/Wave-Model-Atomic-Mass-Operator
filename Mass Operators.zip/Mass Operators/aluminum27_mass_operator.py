
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Aluminum-27
A0 = -3240.1752045126527
k1 = 9.21451330049261
k2 = 3.6297507389162558
gamma = 0.6546

def mass_operator_al27(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_al27(R=3.0617):
    result, _ = quad(mass_operator_al27, 0, R)
    return result
