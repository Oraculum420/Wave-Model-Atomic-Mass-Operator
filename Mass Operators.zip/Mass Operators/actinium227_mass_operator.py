
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Actinium-227
A0 = 11021.506579207466
k1 = 8.065237749546279
k2 = 3.7194736842105267
gamma = 0.6999473684210525

def mass_operator_ac227(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ac227(R=4.606):
    result, _ = quad(mass_operator_ac227, 0, R)
    return result
