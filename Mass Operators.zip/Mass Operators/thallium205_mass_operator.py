
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Thallium-205
A0 = 9797.649449195575
k1 = 8.027614778325121
k2 = 3.6951152709359603
gamma = 0.6728798029556651

def mass_operator_tl205(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_tl205(R=4.634):
    result, _ = quad(mass_operator_tl205, 0, R)
    return result
