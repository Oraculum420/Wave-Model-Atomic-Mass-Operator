
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Berkelium-247
A0 = 12155.878668333788
k1 = 8.077788177339901
k2 = 3.748765517241379
gamma = 0.7474128078817734

def mass_operator_bk247(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_bk247(R=4.583):
    result, _ = quad(mass_operator_bk247, 0, R)
    return result
