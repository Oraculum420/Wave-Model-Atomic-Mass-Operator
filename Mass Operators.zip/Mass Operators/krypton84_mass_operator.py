
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Krypton-84
A0 = 5002.158907034649
k1 = 8.398338494018297
k2 = 3.66815327234342
gamma = 0.652048275862069

def mass_operator_kr84(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_kr84(R=4.073):
    result, _ = quad(mass_operator_kr84, 0, R)
    return result
