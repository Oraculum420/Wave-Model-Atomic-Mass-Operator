
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Praseodymium-141
A0 = 10498.290020997954
k1 = 8.088
k2 = 3.7327295825771327
gamma = 0.68

def mass_operator_pr141(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_pr141(R=4.622):
    result, _ = quad(mass_operator_pr141, 0, R)
    return result
