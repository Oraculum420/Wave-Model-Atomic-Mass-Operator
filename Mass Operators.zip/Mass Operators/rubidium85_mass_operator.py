
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Rubidium-85
A0 = 6715.722708580954
k1 = 7.827737508796623
k2 = 3.681722308233638
gamma = 0.6909172413793103

def mass_operator_rb85(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_rb85(R=4.203):
    result, _ = quad(mass_operator_rb85, 0, R)
    return result
