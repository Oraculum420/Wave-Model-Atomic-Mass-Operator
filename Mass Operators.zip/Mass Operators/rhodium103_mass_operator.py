
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Rhodium-103
A0 = 6167.644409659429
k1 = 8.444856157635467
k2 = 3.7103733990147787
gamma = 0.6922699507389162

def mass_operator_rh103(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_rh103(R=4.343):
    result, _ = quad(mass_operator_rh103, 0, R)
    return result
