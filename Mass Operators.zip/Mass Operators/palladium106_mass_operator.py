
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Palladium-106
A0 = 6186.314428038838
k1 = 8.461954679802956
k2 = 3.7171556650246305
gamma = 0.6877300492610838

def mass_operator_pd106(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_pd106(R=4.362):
    result, _ = quad(mass_operator_pd106, 0, R)
    return result
