
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Francium-223
A0 = 10769.637461683527
k1 = 8.054568472906402
k2 = 3.722787192118227
gamma = 0.693311330049261

def mass_operator_fr223(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_fr223(R=4.614):
    result, _ = quad(mass_operator_fr223, 0, R)
    return result
