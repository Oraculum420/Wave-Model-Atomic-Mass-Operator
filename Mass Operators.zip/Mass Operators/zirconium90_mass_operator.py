
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Zirconium-90
A0 = 6441.417051368446
k1 = 8.296389318122893
k2 = 3.7613321234119783
gamma = 0.6843888514389421

def mass_operator_zr90(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_zr90(R=4.269):
    result, _ = quad(mass_operator_zr90, 0, R)
    return result
