
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Cesium-133
A0 = 6602.845084097925
k1 = 8.255229556650246
k2 = 3.755058128078818
gamma = 0.6862364532019705

def mass_operator_cs133(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_cs133(R=4.507):
    result, _ = quad(mass_operator_cs133, 0, R)
    return result
