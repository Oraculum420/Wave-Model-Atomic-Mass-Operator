
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Technetium-98
A0 = 6082.317524167323
k1 = 8.351609852216749
k2 = 3.7068679802955664
gamma = 0.6949428571428571

def mass_operator_tc98(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_tc98(R=4.327):
    result, _ = quad(mass_operator_tc98, 0, R)
    return result
