
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Calcium-40
A0 = 4722.018992548068
k1 = 8.887651653764955
k2 = 3.5586664320900776
gamma = 0.6829034482758621

def mass_operator_ca40(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ca40(R=3.478):
    result, _ = quad(mass_operator_ca40, 0, R)
    return result
