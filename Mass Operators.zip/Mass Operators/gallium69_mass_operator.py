
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Gallium-69
A0 = 7067.8017128897
k1 = 8.235721463757915
k2 = 3.9146788177339897
gamma = 0.6608896551724137

def mass_operator_ga69(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ga69(R=3.977):
    result, _ = quad(mass_operator_ga69, 0, R)
    return result
