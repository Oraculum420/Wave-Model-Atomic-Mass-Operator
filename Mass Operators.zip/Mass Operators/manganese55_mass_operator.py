
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Manganese-55
A0 = 3045.094438026191
k1 = 9.255150316678396
k2 = 3.8641268121041517
gamma = 0.7198827586206896

def mass_operator_mn55(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_mn55(R=3.705):
    result, _ = quad(mass_operator_mn55, 0, R)
    return result
