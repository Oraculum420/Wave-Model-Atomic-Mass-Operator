
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Titanium-48
A0 = 1601.1336420368516
k1 = 7.743828993666432
k2 = 3.7416778325123157
gamma = 0.6830413793103448

def mass_operator_ti48(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_ti48(R=3.590):
    result, _ = quad(mass_operator_ti48, 0, R)
    return result
