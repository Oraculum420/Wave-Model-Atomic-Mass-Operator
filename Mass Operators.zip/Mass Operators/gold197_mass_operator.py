
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Gold-197
A0 = 9244.409151114756
k1 = 8.01648275862069
k2 = 3.6980000000000004
gamma = 0.664

def mass_operator_au197(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_au197(R=4.642):
    result, _ = quad(mass_operator_au197, 0, R)
    return result
