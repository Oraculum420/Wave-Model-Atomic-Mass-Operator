
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Meitnerium-278
A0 = 13805.96096172762
k1 = 8.078073891625614
k2 = 3.7573842364532015
gamma = 0.8012591133004927

def mass_operator_mt278(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_mt278(R=4.555):
    result, _ = quad(mass_operator_mt278, 0, R)
    return result
