
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Nihonium-286
A0 = 14351.794067892673
k1 = 8.075931034482757
k2 = 3.7330344827586206
gamma = 0.8105825771324865

def mass_operator_nh286(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_nh286(R=4.546):
    result, _ = quad(mass_operator_nh286, 0, R)
    return result
