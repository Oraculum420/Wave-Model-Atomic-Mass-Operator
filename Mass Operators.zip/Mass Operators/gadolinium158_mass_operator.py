
import numpy as np
from scipy.integrate import quad

# Calibrated parameters for Gadolinium-158
A0 = 12362.658637232009
k1 = 8.037999999999998
k2 = 3.7066751361161527
gamma = 0.668

def mass_operator_gd158(r):
    return A0 * np.sin(k1 * r) * np.sin(k2 * r) * np.exp(-gamma * r)

def compute_mass_gd158(R=4.654):
    result, _ = quad(mass_operator_gd158, 0, R)
    return result
