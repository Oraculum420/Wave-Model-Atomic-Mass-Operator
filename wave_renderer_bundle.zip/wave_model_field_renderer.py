"""
USAGE:
    python wave_model_field_renderer.py <mode> <phase_angle> <z_plane> <l_value> <atomic_number> <resolution>

MODES:
    lobed      - Directional angular lobes
    multi      - Multi-source nucleus interference
    orbital    - Angular orbital view (s, p, d, f)

EXAMPLE:
    python wave_model_field_renderer.py orbital 90 0 2 6 400
    (Renders a Carbon d-orbital with 90° phase and central Z-plane)
"""


import math
from PIL import Image, ImageDraw
import sys



# Mapping of atomic number (Z) to element name (first 117)
ELEMENTS = [
    "Hydrogen", "Helium", "Lithium", "Beryllium", "Boron", "Carbon", "Nitrogen", "Oxygen", "Fluorine", "Neon",
    "Sodium", "Magnesium", "Aluminum", "Silicon", "Phosphorus", "Sulfur", "Chlorine", "Argon", "Potassium", "Calcium",
    "Scandium", "Titanium", "Vanadium", "Chromium", "Manganese", "Iron", "Cobalt", "Nickel", "Copper", "Zinc",
    "Gallium", "Germanium", "Arsenic", "Selenium", "Bromine", "Krypton", "Rubidium", "Strontium", "Yttrium", "Zirconium",
    "Niobium", "Molybdenum", "Technetium", "Ruthenium", "Rhodium", "Palladium", "Silver", "Cadmium", "Indium", "Tin",
    "Antimony", "Tellurium", "Iodine", "Xenon", "Cesium", "Barium", "Lanthanum", "Cerium", "Praseodymium", "Neodymium",
    "Promethium", "Samarium", "Europium", "Gadolinium", "Terbium", "Dysprosium", "Holmium", "Erbium", "Thulium", "Ytterbium",
    "Lutetium", "Hafnium", "Tantalum", "Tungsten", "Rhenium", "Osmium", "Iridium", "Platinum", "Gold", "Mercury",
    "Thallium", "Lead", "Bismuth", "Polonium", "Astatine", "Radon", "Francium", "Radium", "Actinium", "Thorium",
    "Protactinium", "Uranium", "Neptunium", "Plutonium", "Americium", "Curium", "Berkelium", "Californium", "Einsteinium", "Fermium",
    "Mendelevium", "Nobelium", "Lawrencium", "Rutherfordium", "Dubnium", "Seaborgium", "Bohrium", "Hassium", "Meitnerium", "Darmstadtium",
    "Roentgenium", "Copernicium", "Nihonium", "Flerovium", "Moscovium", "Livermorium", "Tennessine", "Oganesson"
]


def get_element_name(z):
    if 1 <= z <= len(ELEMENTS):
        return ELEMENTS[z - 1]
    else:
        return "UnknownZ"

def compute_lobed_field(x, y, z, phase_deg):
    r = math.sqrt(x**2 + y**2 + z**2)
    theta = math.atan2(y, x)
    phase = math.radians(phase_deg)
    lobes = math.sin(3 * theta)
    return math.sin(5 * r + phase) * lobes * math.exp(-0.1 * r)

def compute_multisource(x, y, z, phase_deg):
    r1 = math.sqrt((x + 2.5)**2 + y**2 + z**2)
    r2 = math.sqrt((x - 2.5)**2 + y**2 + z**2)
    phase = math.radians(phase_deg)
    amp1 = math.sin(5 * r1 + phase) * math.exp(-0.1 * r1)
    amp2 = math.sin(5 * r2 + phase) * math.exp(-0.1 * r2)
    return amp1 + amp2

def compute_orbital(x, y, z, l=0, m=0, phase_deg=0):
    r = math.sqrt(x**2 + y**2 + z**2)
    if r == 0:
        return 0
    theta = math.atan2(y, x)
    phase = math.radians(phase_deg)
    if l == 0:
        Y = 1
    elif l == 1:
        Y = math.sin(theta)
    elif l == 2:
        Y = math.sin(2 * theta)
    elif l == 3:
        Y = math.sin(3 * theta)
    else:
        Y = 0
    return math.sin(5 * r + phase) * Y * math.exp(-0.1 * r)

def render_wave(mode='lobed', phase_deg=0, z_plane=0.0, l_val=0, size=400, element='custom'):
    image = Image.new("L", (size, size), color=0)
    draw = ImageDraw.Draw(image)
    lim = 10
    scale = (2 * lim) / size

    for i in range(size):
        for j in range(size):
            x = (i - size / 2) * scale
            y = (j - size / 2) * scale

            if mode == 'lobed':
                amp = compute_lobed_field(x, y, z_plane, phase_deg)
            elif mode == 'multi':
                amp = compute_multisource(x, y, z_plane, phase_deg)
            elif mode == 'orbital':
                amp = compute_orbital(x, y, z_plane, l=l_val, phase_deg=phase_deg)
            else:
                amp = 0

            brightness = int(127 + 127 * amp)
            brightness = max(0, min(255, brightness))
            draw.point((i, j), fill=brightness)

    filename = f"{element}_{mode}_phase{phase_deg}_z{z_plane}_l{l_val}.png"
    image.save(filename)
    print("Saved:", filename)

if __name__ == "__main__":
    args = sys.argv[1:]
    mode = args[0] if len(args) > 0 else 'lobed'
    phase = float(args[1]) if len(args) > 1 else 0.0
    z = float(args[2]) if len(args) > 2 else 0.0
    l = int(args[3]) if len(args) > 3 else 0
    z = int(args[4]) if len(args) > 4 else 6
    z = int(args[4]) if len(args) > 4 else 6
    element = get_element_name(z)
    resolution = int(args[5]) if len(args) > 5 else 400

    render_wave(mode, phase, z, l, resolution, element)
