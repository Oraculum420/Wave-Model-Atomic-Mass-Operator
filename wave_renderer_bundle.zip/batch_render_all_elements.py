
import os
import subprocess

MODES = ['lobed', 'multi', 'orbital']
PHASES = [0, 90, 180]
Z_PLANES = [0]
L_VALUES = [0, 1, 2, 3]  # s, p, d, f
RESOLUTION = 300

ELEMENT_COUNT = 117

for mode in MODES:
    for z in range(1, ELEMENT_COUNT + 1):
        for phase in PHASES:
            for z_plane in Z_PLANES:
                lvals = [0] if mode != 'orbital' else L_VALUES
                for l in lvals:
                    cmd = [
                        'python', 'wave_model_field_renderer.py',
                        mode, str(phase), str(z_plane),
                        str(l), str(z), str(RESOLUTION)
                    ]
                    print("Running:", " ".join(cmd))
                    subprocess.run(cmd)
