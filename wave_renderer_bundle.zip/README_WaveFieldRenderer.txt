
# Wave Model Field Renderer

This tool renders visual field slices of atomic and subatomic waveforms using a unified standing wave model.

## Author
Created by **Brian Doyle Lampton**  
Technical Assistance via **Mathematiclese (ChatGPT)**

---

## Files Included

- `wave_model_field_renderer.py`  
  A configurable renderer that supports:
  - Angular Lobed Fields (`lobed`)
  - Multi-Source Interference Fields (`multi`)
  - Orbital Structures (s, p, d, f) via `orbital` mode

- `batch_render_all_elements.py`  
  Loops through all 117 elements and renders images for selected phase angles and wave types.

---

## Usage

### Single Image Rendering:
```bash
python wave_model_field_renderer.py <mode> <phase_angle> <z_plane> <l_value> <atomic_number> <resolution>
```

### Example:
```bash
python wave_model_field_renderer.py orbital 90 0 2 6 400
```

### Batch Rendering:
```bash
python batch_render_all_elements.py
```

This will auto-render lobed, multi, and orbital views across:
- 117 elements
- Phase angles: 0°, 90°, 180°
- Orbital types: s, p, d, f
- Z-slice = 0

---

## Dependencies
- Python 3.x
- Pillow (for image generation)
```bash
pip install pillow
```

---

## Output
PNG images named by mode, atomic number, phase, Z-slice, and orbital type.

